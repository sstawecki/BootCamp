require(['Movie.class','MovieObserver.class'],function(){
	//Incluyo Movie.class que tiene la clase Movie. Movie hereda de Observable asi que dentro de Movie requiero Observable.
	//Observable no requiere nada, asi que dej� dir�ctamente la clase.
	//MovieObserver lo mismo, no requiere nada as� que la escrib� tal cual en un archivo a parte.
});