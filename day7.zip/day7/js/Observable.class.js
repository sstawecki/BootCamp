//Class Observable.
function Observable(){

	this.observers = [];
	//Notify Observers.
	Observable.prototype.notifyObservers = function(){ //Paso data = this y luego pregunto por this.state
		this.observers[0].update(this); //Ac� ir�a un foreach
	}
}