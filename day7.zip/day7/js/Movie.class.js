	//Esto debe estar fallando

require(['Observable.class'],function(){
//Incluyo Observable para que Movie herede de esta.
	//Class Movie extends Observable.
	function Movie(){
		Movie.prototype = new Observable(); // 
		Movie.prototype.constructor = Movie; // Estas 3 l�neas no s� si van ac� dentro o afuera.
		Observable.call(this); //
		var id = null;
		var title = null;
		var rating = null;
		var state = 'stopped';
		
		this.getTitle = function(){
			return title;
		}
		
		this.setTitle = function(t){
			title = t;
		}
		
		this.getId = function(){
			return id;
		}
		
		this.setId = function(newId){
			id = newId;
		}
		
		this.getRating = function(){
			return rating;
		}
		
		this.setRating = function(r){
			rating = r;
		}

		this.play = function(){
			state = 'playing';
			this.notifyObservers(this);
		}
		
		this.stop = function(){
			state = 'stopped';
			this.notifyObservers(this);
		}
		
		this.getState = function(){
			return state;
		}
	}
});